package com.zybooks.weighttrackingapp_projectthree_justinaebi;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import androidx.annotation.Nullable;

public class WeightsDB  extends SQLiteOpenHelper {
    public WeightsDB(Context context) {
        super(context, "Dailyweight.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table Userweights(goal TEXT primary key, date TEXT ,weight TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop Table if exists Userweights");
    }

    // Method for insertion of user weights into a database
    public Boolean insertWeightData(String goal, String date, String weight) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("goal", goal);
        contentValues.put("date", date);
        contentValues.put("weight", weight);

        long result = DB.insert("Userweights", null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    // Method to update any existing data in the weights database
    public Boolean updateWeightData(String goal, String date, String weight) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("date", date);
        contentValues.put("weight", weight);
        Cursor cursor = DB.rawQuery("Select * from Userweights where goal = ?",new String[] {goal});

        if (cursor.getCount() > 0) {
            long result = DB.update("Userweights", contentValues, "goal = ?", new String[] {goal});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    // Method to delete weight data from the database
    public Boolean deleteWeightData(String goal) {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from Userweights where goal = ?",new String[] {goal});

        if (cursor.getCount() > 0) {
            long result = DB.delete("Userweights", "goal = ?", new String[] {goal});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Cursor getData() {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from Userweights", null);
        return cursor;
    }
}
