/*
 * ===========================================================================
 * Thermostat Prototype
 * By: Justin Aebi
 * Description: This is an in-home thermostat prototype. The device accepts
 * two button inputs to change the set temperature on the device and increase
 * or decrease the temperature set point.
 * It will indicate via LED when the heat is turned on or off to imitate the
 * functionality of a real thermostat and heater in a home. The temperature data
 * and heat data as well as time since startup are displayed from the device as
 * well via an upload that occurs every one second.
 *
 * BEFORE CHANGES:
 * Before any changes were made to this project, it would function just fine,
 * however my switch statements lacked case defaults. The timings for button
 * input and temperature reading were too slow. There was also an issue with
 * the set temperature point. It lacked any limit to both the upper and lower
 * temperature point. This was not reflective of a real world thermostat. Some
 * of my comments were lacking in detail and structure.
 *
 * AFTER CHANGES:
 * After reworking this project the switch case defaults were implemented and
 * tested to ensure that a fallback is reached if something were to go wrong.
 * The heat will be turned off, the LED with also turn off and the timer that
 * runs the functions will be disabled. A reset of the device should cause it
 * to resume normal operation in a real world test. Otherwise there is likely
 * hardware faults. The timings for button input and temperature reading were
 * improved to read more frequently as to imitate a person spamming the increase
 * or decrease button as to quickly set a temperature point. Set temperature
 * limits were also introduced and the user is prevented from reaching past that
 * limit.
 * ===========================================================================
 */

/* ===========================================================================
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ===========================================================================
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <unistd.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/Timer.h>
#include <ti/drivers/I2C.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/*UART Driver*/
#define DISPLAY(x) UART_write(uart, &output, x);

// UART Global Variables
char output[64];
int bytesToSend;

// Driver Handles - Global variables
UART_Handle uart;

// Driver setup for the UART
/* ===========================================================================
 * This is needed to initialize the UART for timings for the timer functionality.
 * Params can be changed to your liking if you know what you are doing.
 * ===========================================================================
 */
void initUART(void)
{
    UART_Params uartParams;
    // Init the driver
    UART_init();
    // Configure the driver
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;

    // Open the driver
    uart = UART_open(CONFIG_UART_0, &uartParams);

    if (uart == NULL) {
        /* UART_open() failed */
        while (1);
    }
}

/*I2C Driver*/
// I2C Global Variables

static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
}

sensors[3] = {
    { 0x48, 0x0000, "11X" },
    { 0x49, 0x0000, "116" },
    { 0x41, 0x0001, "006" }
};

uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;

// Driver Handles - Global variables
I2C_Handle i2c;

// Make sure you call initUART() before calling this function.
/* ===========================================================================
 * Driver setup for the I2C. This driver uses up the remaining slots that could
 * otherwise be used for additional LEDs to function but is required to read the
 * room temperature. So only 1 LED can be altered in this program because of this.
 * ===========================================================================
 */
void initI2C(void)
{
    int8_t i, found;
    I2C_Params i2cParams;
    DISPLAY(snprintf(output, 64, "Initializing I2C Driver - "))

    // Init the driver
    I2C_init();
    // Configure the driver
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;
    // Open the driver
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);

    if (i2c == NULL)
    {
        DISPLAY(snprintf(output, 64, "Failed\n\r"))
        while (1);
    }

    DISPLAY(snprintf(output, 32, "Passed\n\r"))

    // Boards were shipped with different sensors.
    // Welcome to the world of embedded systems.
    // Try to determine which sensor we have.
    // Scan through the possible sensor addresses
    /* Common I2C transaction setup */
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;

    found = false;
    for (i=0; i<3; ++i)
    {
        i2cTransaction.slaveAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;
        DISPLAY(snprintf(output, 64, "Is this %s? ", sensors[i].id))
        if (I2C_transfer(i2c, &i2cTransaction))
        {
            DISPLAY(snprintf(output, 64, "Found\n\r"))
            found = true;
            break;
        }
        DISPLAY(snprintf(output, 64, "No\n\r"))
    }

    if(found)
    {
        DISPLAY(snprintf(output, 64, "Detected TMP%s I2C address: %x\n\r", sensors[i].id, i2cTransaction.slaveAddress))
    }
    else
    {
        DISPLAY(snprintf(output, 64, "Temperature sensor not found.\n\r"))
    }
}

/* ===========================================================================
 * This function will read the temperature and output it via degrees Celsius.
 * ===========================================================================
 */
int16_t readTemp(void)
{
    int16_t temperature = 0;

    i2cTransaction.readCount = 2;
    if (I2C_transfer(i2c, &i2cTransaction))
    {
        /*
         * Extract degrees C from the received data;
         * see TMP sensor datasheet
         */
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        temperature *= 0.0078125;
        /*
         * If the MSB is set '1', then we have a 2's complement
         * negative value which needs to be sign extended
         */
        if (rxBuffer[0] & 0x80)
        {
            temperature |= 0xF000;
        }
    }
    else
    {
        DISPLAY(snprintf(output, 64, "Error reading temperature sensor %d\n\r", i2cTransaction.status))
        DISPLAY(snprintf(output, 64, "Please power cycle your board by unplugging USB and plugging back in.\n\r"))
    }
    return temperature;
}

/*Timer Drivers*/
// Driver Handles - Global variables
Timer_Handle timer0;

/* flag checks
 * ===========================================================================
 * TimerFlag and ButtonFlag's are utilized to interrupt the device to detect
 * any changes such as a button being pressed or the timer needing to be stopped.
 * ===========================================================================
 */
volatile unsigned char TimerFlag = 0;
volatile unsigned char Button1Flag = 0;
volatile unsigned char Button2Flag = 0;

// Needed for timer functionality
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    TimerFlag = 1;
}

/* Function to initialize the timer and setup parameters.
 * ===========================================================================
 * This function initializes the timer and sets up the parameters for the timer.
 * You can alter any of the parameters however you please. The params.period
 * sets the millisecond time that the timer will operate at. 1000 = 1ms.
 * ===========================================================================
 */
void initTimer(void)
{
    Timer_Params params;

    // Init the driver
    Timer_init();

    // Configure the driver
    Timer_Params_init(&params);

    //Every 100 milliseconds
    params.period = 100000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    // Open the driver
    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    if (timer0 == NULL) {
        /* Failed to initialized timer */
        while (1) {}
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }
}

/* Declaration of the state machines
 * ===========================================================================
 * State machines are utilized to change the current task at hand. TMP_states
 * is for the temperature, UP_states is for upload sequences, BTN_states is
 * for the button inputs, and LED_states is for LED sequences such as flashing.
 * ===========================================================================
 */
enum TMP_states {TMP_SMStart, TMP_Read} TMP_state;
enum UP_states {UP_SMStart, UP_Send} UP_state;
enum BTN_states {BTN_SMStart, BTN_1_Flag, BTN_2_Flag,} BTN_state;
enum LED_states {LED_SMStart, LED_On, LED_Off, LED_Blink} LED_state;

// temperature display outputs
int setTemp = 20; // default temperature set to 20*C / 68*F.
int16_t currentTemp = 0;
volatile unsigned char heat = 0; // In a real world scenario, this will toggle the output of the device to enable the in-home heater to turn on or off.
int seconds = 0;

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *  *NOTES*:
 *  GPIO interrupts are cleared prior to invoking callbacks.
 *  CONFIG_GPIO_BUTTON_1 cannot be used at the same time as CONFIG_GPIO_BUTTON_0 as I2C drivers
 *  utilize the pins needed to get the LED to function.
 */
void gpioButtonFxn0(uint_least8_t index)
{
    // When button SW2 is pressed set flag to toggle on. Indicating the button was pressed.
    Button1Flag = 1;
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *  *NOTES*:
 *  This may not be used for all boards.
 *  GPIO interrupts are cleared prior to invoking callbacks.
 *  CONFIG_GPIO_BUTTON_1 cannot be used at the same time as CONFIG_GPIO_BUTTON_0 as I2C drivers
 *  utilize the pins needed to get the LED to function.
 */
void gpioButtonFxn1(uint_least8_t index)
{
    // When button SW3 is pressed set flag to toggle on. Indicating the button was pressed.
    Button2Flag = 1;
}

// Function to change the LED states. Change usleep() parameters to alter speed.
void TickFct_LED() {
    switch (LED_state) {
        case LED_SMStart:
            TimerFlag = 0;
            break;
        case LED_On: // indicate heat is on
            heat = 1;
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            break;
        case LED_Off: // indicate heat is off
            heat = 0;
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            break;
        case LED_Blink: // indicate upload sequence
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            usleep(70000);
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            usleep(20000);
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            usleep(70000);
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            usleep(20000);
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            break;
        default:
            DISPLAY(snprintf(output,64, "Failed to toggle LED. Please restart the thermostat.\n"))
            LED_state = LED_Off;
            Timer_stop(timer0);
            break;
    }
}

/* Function to upload temperature data to COM port.
 *  ===========================================================================
 *  You may need to figure out which COM port is used. Just open your device manager
 *  and go to PORTS and plug in the device. Two should pop up and it will be one
 *  of those ports.
 *  ===========================================================================
 */
void TickFct_Upload() {
    switch (UP_state) {
        case UP_SMStart: // begin upload process
            TimerFlag = 0;
            UP_state = UP_Send;
            break;
        case UP_Send: // indicate LED upload light and output to COM port temperature readings
            LED_state = LED_Blink;
            DISPLAY(snprintf(output,64, "<%02d,%02d,%d,%04d>\n\r", currentTemp, setTemp, heat, seconds))
            break;
        default:
            DISPLAY(snprintf(output,64, "Failed to upload data to screen. Please restart the thermostat.\n"))
            LED_state = LED_Off;
            Timer_stop(timer0);
            break;
    }
}

// Function to read temperature.
void TickFct_Temp() {
    switch (TMP_state) {
        case TMP_SMStart: // begin temp read process
            TimerFlag = 0;
            TMP_state = TMP_Read;
            break;
        case TMP_Read: // read current temp and check with set temp
            currentTemp = readTemp();
            if (currentTemp <= setTemp) {
                LED_state = LED_On;
            }
            if (currentTemp > setTemp) {
                LED_state = LED_Off;
            }
            break;
        default: // In case something goes wrong, the LED will turn off and timer will stop. Heat will also turn off.
            DISPLAY(snprintf(output,64, "Failed to read temperature, turning off heat. Please restart the thermostat.\n"))
            LED_state = LED_Off;
            heat = 0;
            Timer_stop(timer0);
            break;
    }
}

// Function to read button inputs and check validity of temperature limits.
void TickFct_Button() {
    switch (BTN_state) {
        case BTN_SMStart: // read for button flag and switch case if flagged
            TimerFlag = 0;
            if (Button1Flag == 1) {
                BTN_state = BTN_1_Flag;
            }
            if (Button2Flag == 1) {
                BTN_state = BTN_2_Flag;
            }
            break;
        case BTN_1_Flag: // button 1 flagged, increase set temp, reset flag, read for button flag again

            // Check to see if button input exceeds upper or lower limits. If so, default the temperature to max or min.
            if (setTemp >= 38) {
                setTemp -= 1;
            } else if (setTemp <= 0) {
                setTemp += 1;
            } else {
                setTemp += 1;
            }
            Button1Flag = 0;
            BTN_state = BTN_SMStart;
            break;
        case BTN_2_Flag: // button 2 flagged, decrease set temp, reset flag, read for button flag again
            if (setTemp <= 0) {
                setTemp += 1;
            } else if (setTemp >= 38) {
                setTemp -= 1;
            } else {
                setTemp -= 1;
            }
            Button2Flag = 0;
            BTN_state = BTN_SMStart;
            break;
        default: // In case something goes wrong, the LED will turn off and timer will stop.
            DISPLAY(snprintf(output,64, "Failed to read button inputs. Please restart the thermostat.\n"))
            LED_state = LED_Off;
            Timer_stop(timer0);
            break;
    }
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    unsigned long UP_elapsedTime = 1000; // 1s
    unsigned long TMP_elapsedTime = 200; // 200ms
    unsigned long BTN_elapsedTime = 100; // 100ms
    const unsigned long timerPeriod = 100; // 100ms

    /* Call driver init functions */
    GPIO_init();
    initUART();
    initI2C(); // always call initUART() before this
    initTimer();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    // Initialize state machines
    LED_state = LED_SMStart;
    TMP_state = TMP_SMStart;
    UP_state = UP_SMStart;
    BTN_state = BTN_SMStart;

    while(1){
        /* While we are not done with the timer */
        if (BTN_elapsedTime >= 100) {
            TickFct_Button(); // execute one tick of button read state.
            BTN_elapsedTime = 0;
        }
        if (UP_elapsedTime >= 1000) {
            TickFct_Upload(); // execute one tick of upload state.
            TickFct_LED(); // execute LED state to indicate upload
            UP_elapsedTime = 0;
            seconds += 1; // increment seconds passed
        }
        if (TMP_elapsedTime >= 200) {
            TickFct_Temp(); // execute one tick of temp read state.
            TickFct_LED(); // execute LED state to indicate heat on/off
            TMP_elapsedTime = 0;
        }

        while(!TimerFlag){}
        /* Set the timer flag variable to FALSE */
        TimerFlag = 0;
        // increment timers
        UP_elapsedTime += timerPeriod;
        TMP_elapsedTime += timerPeriod;
        BTN_elapsedTime += timerPeriod;

    }
    return (NULL);
}
